chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id) return;
  chrome.tabs.sendMessage(tab.id, { type: "ark-toggle" }).catch(() => {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });
    chrome.scripting.insertCSS({
      target: { tabId: tab.id },
      files: ["overlay.css"]
    });
  });
});
