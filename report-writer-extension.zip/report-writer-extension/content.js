(function () {
  if (window.__assistiveReportKeyboardLoaded) return;
  window.__assistiveReportKeyboardLoaded = true;

  let activeTarget = null;
  let root = null;
  let textBuffer = "";
  let dwellMs = 0;

  const predictions = ["the", "and", "report", "result"];
  const rows = [
    ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"],
    ["a", "s", "d", "f", "g", "h", "j", "k", "l", "'"],
    ["z", "x", "c", "v", "b", "n", "m", ",", ".", "?"]
  ];

  document.addEventListener("focusin", (event) => {
    if (isEditable(event.target)) activeTarget = event.target;
  });

  chrome.runtime.onMessage.addListener((message) => {
    if (message && message.type === "ark-toggle") toggle();
  });

  function isEditable(node) {
    if (!node || node === document.body) return false;
    const tag = (node.tagName || "").toLowerCase();
    return tag === "textarea" ||
      tag === "input" ||
      node.isContentEditable ||
      node.getAttribute("role") === "textbox";
  }

  function toggle() {
    if (!root) createOverlay();
    root.classList.toggle("ark-hidden");
  }

  function createOverlay() {
    root = document.createElement("div");
    root.id = "ark-root";
    root.innerHTML = `
      <div class="ark-panel">
        <div class="ark-head">
          <div>
            <div class="ark-brand">REPORT KEYBOARD</div>
            <div class="ark-sub">Focus a text box, then type here.</div>
          </div>
          <button class="ark-close" title="Hide">x</button>
        </div>
        <div class="ark-display" id="ark-display"></div>
        <div class="ark-preds" id="ark-preds"></div>
        <div class="ark-keys" id="ark-keys"></div>
        <div class="ark-bottom">
          <label>DWELL <input id="ark-dwell" type="range" min="0" max="1500" step="100" value="0"></label>
          <span id="ark-dwell-value">off</span>
          <button class="ark-small" id="ark-clear">Clear</button>
        </div>
      </div>
    `;
    document.documentElement.appendChild(root);

    root.querySelector(".ark-close").addEventListener("click", () => root.classList.add("ark-hidden"));
    root.querySelector("#ark-clear").addEventListener("click", () => {
      textBuffer = "";
      renderDisplay();
    });
    root.querySelector("#ark-dwell").addEventListener("input", (event) => {
      dwellMs = Number(event.target.value);
      root.querySelector("#ark-dwell-value").textContent = dwellMs ? `${dwellMs}ms` : "off";
    });

    renderPredictions();
    renderKeys();
    renderDisplay();
  }

  function renderDisplay() {
    const display = root.querySelector("#ark-display");
    display.textContent = textBuffer || "Ready";
  }

  function renderPredictions() {
    const wrap = root.querySelector("#ark-preds");
    wrap.innerHTML = "";
    predictions.forEach((word) => {
      wrap.appendChild(makeButton(word, () => insertText(word + " "), "ark-pred"));
    });
  }

  function renderKeys() {
    const wrap = root.querySelector("#ark-keys");
    wrap.innerHTML = "";

    rows.forEach((row) => {
      const rowEl = document.createElement("div");
      rowEl.className = "ark-row";
      row.forEach((key) => rowEl.appendChild(makeButton(key, () => insertText(key), "ark-key")));
      wrap.appendChild(rowEl);
    });

    const bottom = document.createElement("div");
    bottom.className = "ark-row ark-row-bottom";
    bottom.appendChild(makeButton("⌫", backspace, "ark-key ark-fn"));
    bottom.appendChild(makeButton("↵", () => insertText("\n"), "ark-key ark-fn"));
    bottom.appendChild(makeButton("SPACE", () => insertText(" "), "ark-key ark-space"));
    bottom.appendChild(makeButton("AI", showAiPlaceholder, "ark-key ark-fn"));
    wrap.appendChild(bottom);
  }

  function makeButton(label, action, className) {
    const button = document.createElement("button");
    button.className = className;
    button.textContent = label;
    bindDwell(button, action);
    return button;
  }

  function bindDwell(button, action) {
    let timer = null;
    const fire = () => {
      if (timer) clearTimeout(timer);
      timer = null;
      action();
    };
    button.addEventListener("click", fire);
    button.addEventListener("mouseenter", () => {
      if (!dwellMs) return;
      button.classList.add("ark-dwelling");
      timer = setTimeout(fire, dwellMs);
    });
    button.addEventListener("mouseleave", () => {
      button.classList.remove("ark-dwelling");
      if (timer) clearTimeout(timer);
      timer = null;
    });
  }

  function insertText(text) {
    if (!activeTarget || !document.contains(activeTarget)) {
      activeTarget = document.activeElement;
    }
    if (!isEditable(activeTarget)) {
      textBuffer += text;
      renderDisplay();
      return;
    }

    activeTarget.focus();
    if (activeTarget.isContentEditable || activeTarget.getAttribute("role") === "textbox") {
      document.execCommand("insertText", false, text);
    } else {
      const start = activeTarget.selectionStart ?? activeTarget.value.length;
      const end = activeTarget.selectionEnd ?? activeTarget.value.length;
      const value = activeTarget.value || "";
      activeTarget.value = value.slice(0, start) + text + value.slice(end);
      const next = start + text.length;
      activeTarget.selectionStart = next;
      activeTarget.selectionEnd = next;
      activeTarget.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
    }

    textBuffer += text;
    renderDisplay();
  }

  function backspace() {
    if (!activeTarget || !isEditable(activeTarget)) {
      textBuffer = textBuffer.slice(0, -1);
      renderDisplay();
      return;
    }

    activeTarget.focus();
    if (activeTarget.isContentEditable || activeTarget.getAttribute("role") === "textbox") {
      document.execCommand("delete", false);
    } else {
      const start = activeTarget.selectionStart ?? activeTarget.value.length;
      const end = activeTarget.selectionEnd ?? activeTarget.value.length;
      if (start === end && start > 0) {
        activeTarget.value = activeTarget.value.slice(0, start - 1) + activeTarget.value.slice(end);
        activeTarget.selectionStart = start - 1;
        activeTarget.selectionEnd = start - 1;
      } else {
        activeTarget.value = activeTarget.value.slice(0, start) + activeTarget.value.slice(end);
        activeTarget.selectionStart = start;
        activeTarget.selectionEnd = start;
      }
      activeTarget.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "deleteContentBackward" }));
    }
    textBuffer = textBuffer.slice(0, -1);
    renderDisplay();
  }

  function showAiPlaceholder() {
    insertText("[AI Assist coming soon] ");
  }
})();
